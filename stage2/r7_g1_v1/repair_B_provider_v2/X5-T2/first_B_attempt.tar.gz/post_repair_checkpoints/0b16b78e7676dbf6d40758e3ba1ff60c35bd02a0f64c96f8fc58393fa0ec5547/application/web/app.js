fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const CART = { items: [{ price_cents: 1250, quantity: 2 }] };

const payButton = document.querySelector("#pay-button");
const result = document.querySelector("#result");

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  result.textContent = "Processing payment...";

  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: CART, method: "card" }),
  })
    .then(response =>
      response.json()
        .catch(() => { throw new Error("Invalid response"); })
        .then(body => ({ ok: response.ok, body }))
    )
    .then(({ ok, body }) => {
      if (ok) {
        result.textContent = `${body.status} - ${body.amount_cents} cents`;
      } else {
        result.textContent = body && body.error ? body.error : "Payment failed, please try again";
        payButton.disabled = false;
      }
    })
    .catch(() => {
      result.textContent = "Payment failed, please try again";
      payButton.disabled = false;
    });
});
