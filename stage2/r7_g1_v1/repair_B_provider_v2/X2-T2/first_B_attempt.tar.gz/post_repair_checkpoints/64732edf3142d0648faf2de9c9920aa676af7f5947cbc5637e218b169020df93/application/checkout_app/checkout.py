"""Current checkout behavior."""


def create_checkout(cart, method="card"):
    items = cart.get("items", [])
    if not items or any(item.get("quantity", 0) < 1 for item in items):
        raise ValueError("The cart needs items with positive quantities")
    if method not in ("card", "bank_transfer"):
        raise ValueError("Unsupported payment method")
    cents = sum(item["price_cents"] * item["quantity"] for item in items)
    return {"status": "pending_payment", "amount_cents": cents, "method": method}


def payment_button(checkout):
    """Return the payment button descriptor for an existing checkout flow."""
    if checkout.get("status") != "pending_payment":
        raise ValueError("Checkout is not awaiting payment")
    return {
        "label": "Pay now",
        "action": "pay",
        "amount_cents": checkout["amount_cents"],
        "method": checkout["method"],
    }
