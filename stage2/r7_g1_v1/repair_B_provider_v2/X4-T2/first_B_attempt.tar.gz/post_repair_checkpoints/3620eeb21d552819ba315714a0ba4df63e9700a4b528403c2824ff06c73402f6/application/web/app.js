const statusEl = document.querySelector("#status");
const resultEl = document.querySelector("#result");
const payButton = document.querySelector("#pay");

const cart = { items: [{ price_cents: 1250, quantity: 2 }] };

function setResult(message) {
  resultEl.textContent = message;
}

fetch("/api/status")
  .then(response => response.json())
  .then(status => {
    statusEl.textContent = `Checkout ${status.version}`;
    payButton.disabled = false;
  })
  .catch(() => {
    statusEl.textContent = "Checkout unavailable";
    setResult("Could not load checkout status.");
  });

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  setResult("Processing payment...");
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method: "card" })
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      if (!ok) {
        setResult(`Payment failed: ${body.error}`);
      } else {
        setResult(`Payment ${body.status} for $${(body.amount_cents / 100).toFixed(2)} via ${body.method}.`);
      }
    })
    .catch(() => setResult("Payment failed: network error"))
    .finally(() => { payButton.disabled = false; });
});
