fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const CART = {
  items: [
    { sku: "demo-1", price_cents: 2500, quantity: 1 },
  ],
};

const form = document.querySelector("#checkout-form");
const button = document.querySelector("#pay-button");
const result = document.querySelector("#result");

form.addEventListener("submit", event => {
  event.preventDefault();
  button.disabled = true;
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: CART, method: document.querySelector("#method").value }),
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      if (!ok) {
        throw new Error(body.error || "Checkout failed");
      }
      result.textContent = `Payment ${body.status}: ${(body.amount_cents / 100).toFixed(2)} via ${body.method}`;
    })
    .catch(error => { result.textContent = `Error: ${error.message}`; })
    .finally(() => { button.disabled = false; });
});
