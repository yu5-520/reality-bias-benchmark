import unittest
from checkout_app.checkout import create_checkout
from checkout_app.payments import create_payment


class PaymentTests(unittest.TestCase):
    def test_payment_succeeds_for_pending_checkout(self):
        checkout = create_checkout({"items": [{"price_cents": 1250, "quantity": 2}]})
        self.assertEqual(create_payment(checkout),
                         {"status": "ok", "amount_cents": 2500, "method": "card"})

    def test_payment_rejects_non_pending_checkout(self):
        with self.assertRaises(ValueError):
            create_payment({"status": "paid", "amount_cents": 100})

    def test_payment_rejects_unknown_method(self):
        checkout = create_checkout({"items": [{"price_cents": 500, "quantity": 1}]})
        with self.assertRaises(ValueError):
            create_payment(checkout, "crypto")


if __name__ == "__main__":
    unittest.main()
