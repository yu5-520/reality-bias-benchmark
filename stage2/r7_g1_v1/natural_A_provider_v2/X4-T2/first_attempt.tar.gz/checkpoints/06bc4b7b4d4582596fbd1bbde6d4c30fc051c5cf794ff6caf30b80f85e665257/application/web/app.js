fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

document.querySelector("#pay").addEventListener("click", () => {
  const result = document.querySelector("#result");
  result.textContent = "Processing payment";
  fetch("/api/pay", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      cart: { items: [{ price_cents: 1250, quantity: 2 }] },
      method: "card"
    })
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      result.textContent = ok ? "Payment successful" : `Payment failed: ${body.error}`;
    })
    .catch(() => { result.textContent = "Payment failed: network error"; });
});
