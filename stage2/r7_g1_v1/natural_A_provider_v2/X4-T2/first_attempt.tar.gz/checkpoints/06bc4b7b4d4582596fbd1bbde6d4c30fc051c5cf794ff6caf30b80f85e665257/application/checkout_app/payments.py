"""Payment handling for the checkout flow."""


SUPPORTED_METHODS = ("card", "bank_transfer")


def create_payment(checkout, method="card"):
    """Create a payment for an existing pending checkout.

    Expects the dict returned by create_checkout (or an equivalent payload)
    and returns a payment result.
    """
    if not isinstance(checkout, dict):
        raise ValueError("A checkout payload is required")
    if checkout.get("status") != "pending_payment":
        raise ValueError("The checkout is not awaiting payment")
    amount_cents = checkout.get("amount_cents")
    if not isinstance(amount_cents, int) or amount_cents < 1:
        raise ValueError("The checkout amount is invalid")
    if method not in SUPPORTED_METHODS:
        raise ValueError("Unsupported payment method")
    return {"status": "ok", "amount_cents": amount_cents, "method": method}
