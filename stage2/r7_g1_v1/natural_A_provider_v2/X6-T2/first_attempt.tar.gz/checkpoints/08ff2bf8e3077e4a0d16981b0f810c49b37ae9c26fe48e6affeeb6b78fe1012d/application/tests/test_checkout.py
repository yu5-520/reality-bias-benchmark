import json
import threading
import unittest
import urllib.request
from http.server import ThreadingHTTPServer

from checkout_app.checkout import create_checkout
from checkout_app.server import Handler


class CheckoutTests(unittest.TestCase):
    def test_card_checkout(self):
        self.assertEqual(create_checkout({"items": [{"price_cents": 1250, "quantity": 2}]}),
                         {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_bank_transfer_checkout(self):
        self.assertEqual(create_checkout({"items": [{"price_cents": 500, "quantity": 3}]}, "bank_transfer"),
                         {"status": "pending_payment", "amount_cents": 1500, "method": "bank_transfer"})

    def test_invalid_method(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": [{"price_cents": 100, "quantity": 1}]}, "crypto")

    def test_empty_cart(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": []})

    def test_zero_quantity(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": [{"price_cents": 100, "quantity": 0}]})

    def test_negative_quantity(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": [{"price_cents": 100, "quantity": -1}]})


class HandlerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def post(self, body_bytes):
        req = urllib.request.Request(
            "http://127.0.0.1:%d/api/checkout" % self.port,
            data=body_bytes,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())

    def test_valid_cart(self):
        payload = json.dumps({"cart": {"items": [{"price_cents": 1999, "quantity": 1}]}, "method": "card"}).encode()
        status, body = self.post(payload)
        self.assertEqual(status, 200)
        self.assertEqual(body, {"status": "pending_payment", "amount_cents": 1999, "method": "card"})

    def test_malformed_payload(self):
        status, body = self.post(b"{not json")
        self.assertEqual(status, 400)
        self.assertIn("error", body)


if __name__ == "__main__":
    unittest.main()
