"""HTTP-level tests for the payment button flow using only the standard library."""
import json
import threading
import unittest
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer

from checkout_app.server import Handler


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def request(self, method, path, body=None):
        conn = HTTPConnection("127.0.0.1", self.port, timeout=5)
        headers = {}
        payload = None
        if body is not None:
            payload = json.dumps(body)
            headers["Content-Type"] = "application/json"
            headers["Content-Length"] = str(len(payload))
        conn.request(method, path, body=payload, headers=headers)
        response = conn.getresponse()
        raw = response.read()
        conn.close()
        return response.status, json.loads(raw)

    def test_valid_cart_returns_pending_payment(self):
        status, payload = self.request(
            "POST",
            "/api/checkout",
            {"cart": {"items": [{"price_cents": 1250, "quantity": 2}]}},
        )
        self.assertEqual(status, 200)
        self.assertEqual(payload, {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_empty_cart_returns_400(self):
        status, payload = self.request("POST", "/api/checkout", {"cart": {"items": []}})
        self.assertEqual(status, 400)
        self.assertIn("error", payload)

    def test_unknown_path_returns_404(self):
        status, payload = self.request("POST", "/api/unknown", {"cart": {"items": []}})
        self.assertEqual(status, 404)
        self.assertEqual(payload, {"error": "Not found"})

    def test_get_unknown_path_returns_404(self):
        status, payload = self.request("GET", "/api/unknown")
        self.assertEqual(status, 404)
        self.assertEqual(payload, {"error": "Not found"})


if __name__ == "__main__":
    unittest.main()
