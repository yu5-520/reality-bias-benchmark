fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const CART = {
  items: [
    { price_cents: 1999, quantity: 1 },
  ],
};

const payButton = document.querySelector("#pay-button");
const result = document.querySelector("#result");

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  result.textContent = "Processing payment\u2026";

  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: CART, method: "card" }),
  })
    .then(response =>
      response.json().then(body => ({ ok: response.ok, body }))
    )
    .then(({ ok, body }) => {
      if (!ok) {
        throw new Error(body.error || "Payment failed");
      }
      const amount = (body.amount_cents / 100).toFixed(2);
      result.textContent = `Payment ${body.status.replace(/_/g, " ")}: $${amount} (${body.method})`;
    })
    .catch(error => {
      result.textContent = `Unable to complete payment: ${error.message}`;
    })
    .finally(() => {
      payButton.disabled = false;
    });
});
