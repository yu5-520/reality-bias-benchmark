const CART = { items: [{ price_cents: 1250, quantity: 1 }] };

fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

document.querySelector("#pay").addEventListener("click", () => {
  const result = document.querySelector("#result");
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: CART, method: "card" })
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      result.textContent = ok
        ? `Payment ${body.status}: ${(body.amount_cents / 100).toFixed(2)} via ${body.method}`
        : `Payment failed: ${body.error}`;
    })
    .catch(() => { result.textContent = "Payment failed: network error"; });
});
