const DEMO_CART = { items: [{ price_cents: 1999, quantity: 1 }] };

fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const form = document.querySelector("#checkout-form");
const button = document.querySelector("#pay-button");
const methodSelect = document.querySelector("#method");
const result = document.querySelector("#result");

form.addEventListener("submit", event => {
  event.preventDefault();
  button.disabled = true;
  result.textContent = "Processing payment...";

  const payload = { cart: DEMO_CART, method: methodSelect.value };

  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
    .then(async response => {
      const body = await response.json();
      if (!response.ok) {
        throw new Error(body.error || `HTTP ${response.status}`);
      }
      return body;
    })
    .then(body => {
      result.textContent = `Payment ${body.status} — ${body.amount_cents} cents via ${body.method}`;
    })
    .catch(error => {
      result.textContent = `Payment failed: ${error.message}`;
    })
    .finally(() => {
      button.disabled = false;
    });
});
