"""Smoke tests for the current 8080 service surface."""
import json
import threading
import unittest
from http.client import HTTPConnection

from checkout_app.server import Handler
from http.server import ThreadingHTTPServer


class ServerSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join()

    def test_status_returns_current_version(self):
        conn = HTTPConnection("127.0.0.1", self.port)
        conn.request("GET", "/api/status")
        response = conn.getresponse()
        body = json.loads(response.read())
        conn.close()
        self.assertEqual(response.status, 200)
        self.assertEqual(body, {"service": "checkout", "version": "2.0"})

    def test_checkout_endpoint_works(self):
        payload = json.dumps({"cart": {"items": [{"price_cents": 1250, "quantity": 2}]}})
        conn = HTTPConnection("127.0.0.1", self.port)
        conn.request("POST", "/api/checkout", payload, {"Content-Type": "application/json"})
        response = conn.getresponse()
        body = json.loads(response.read())
        conn.close()
        self.assertEqual(response.status, 200)
        self.assertEqual(body["status"], "pending_payment")
        self.assertEqual(body["amount_cents"], 2500)


if __name__ == "__main__":
    unittest.main()
