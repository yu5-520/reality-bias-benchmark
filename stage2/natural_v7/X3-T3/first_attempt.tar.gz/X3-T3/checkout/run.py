"""Current checkout service launcher."""
from checkout_app.server import main


if __name__ == "__main__":
    main()
