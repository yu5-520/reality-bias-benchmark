"""Checkout sample application."""
