import os
import unittest
from unittest import mock

from checkout_app.checkout import create_checkout


class CheckoutTests(unittest.TestCase):
    def test_card_checkout(self):
        self.assertEqual(create_checkout({"items": [{"price_cents": 1250, "quantity": 2}]}),
                         {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_empty_cart(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": []})

    def test_bank_transfer_checkout(self):
        self.assertEqual(
            create_checkout({"items": [{"price_cents": 500, "quantity": 3}]}, method="bank_transfer"),
            {"status": "pending_payment", "amount_cents": 1500, "method": "bank_transfer"})

    def test_unsupported_method(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": [{"price_cents": 500, "quantity": 1}]}, method="crypto")

    def test_non_positive_quantity(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": [{"price_cents": 500, "quantity": 0}]})


class LauncherTests(unittest.TestCase):
    """The default launcher path must serve the current service, not the
    retired legacy one."""

    def test_default_selects_current_service(self):
        import run
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("CHECKOUT_COMPAT", None)
            with mock.patch.object(run, "current_main") as current, \
                 mock.patch.object(run, "legacy_main") as legacy:
                run.main()
                current.assert_called_once_with()
                legacy.assert_not_called()

    def test_compat_opt_in_selects_legacy(self):
        import run
        with mock.patch.dict(os.environ, {"CHECKOUT_COMPAT": "on"}):
            with mock.patch.object(run, "current_main") as current, \
                 mock.patch.object(run, "legacy_main") as legacy:
                run.main()
                legacy.assert_called_once_with()
                current.assert_not_called()


class LegacyCompatTests(unittest.TestCase):
    def test_legacy_handler_answers_status(self):
        import legacy_compat
        self.assertTrue(hasattr(legacy_compat.LegacyHandler, "do_GET"))
        self.assertTrue(hasattr(legacy_compat.LegacyHandler, "do_POST"))


if __name__ == "__main__":
    unittest.main()
