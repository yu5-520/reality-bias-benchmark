"""Service launcher for the current (v2.0) release.

The current checkout service is the default executable path. The legacy
compatibility shim is only used when explicitly opted into via
``CHECKOUT_COMPAT=on``; it is off by default so the launcher serves the
updated service rather than the retired v1 path.
"""
import os
from checkout_app.server import main as current_main
from legacy_compat import main as legacy_main


def main():
    if os.getenv("CHECKOUT_COMPAT", "off") == "on":
        legacy_main()
    else:
        current_main()


if __name__ == "__main__":
    main()
