"""Old v1 HTTP path, retained temporarily across the upgrade.

This shim is opt-in (``CHECKOUT_COMPAT=on``) and listens on 8081 so it can
run alongside the current v2.0 service on 8080. It answers ``GET /api/status``
so the frontend status probe does not fail, and returns 410 for the retired
checkout endpoint.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import json


class LegacyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/status":
            return self.reply(200, {"service": "checkout", "version": "1.9", "legacy": True})
        self.reply(404, {"error": "Not found"})

    def do_POST(self):
        self.reply(410, {"error": "Legacy checkout retired"})

    def reply(self, status, value):
        body = json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main():
    ThreadingHTTPServer(("127.0.0.1", 8081), LegacyHandler).serve_forever()
