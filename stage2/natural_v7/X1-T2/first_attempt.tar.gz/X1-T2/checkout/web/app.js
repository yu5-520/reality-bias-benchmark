// Sample cart used to exercise the existing checkout flow.
const CART = { items: [{ price_cents: 1250, quantity: 2 }] };

fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const form = document.querySelector("#checkout-form");
const button = document.querySelector("#pay-button");
const result = document.querySelector("#result");

form.addEventListener("submit", event => {
  event.preventDefault();
  const method = document.querySelector("#method").value;
  button.disabled = true;
  result.textContent = "Processing payment…";

  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: CART, method })
  })
    .then(async response => {
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Checkout failed");
      }
      return data;
    })
    .then(data => {
      const amount = (data.amount_cents / 100).toFixed(2);
      result.textContent = `Payment ${data.status} — ${amount} via ${data.method}`;
    })
    .catch(error => {
      result.textContent = `Error: ${error.message}`;
    })
    .finally(() => {
      button.disabled = false;
    });
});
