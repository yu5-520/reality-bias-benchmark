import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from checkout_app.checkout import create_checkout
from checkout_app.server import Handler


class CheckoutTests(unittest.TestCase):
    def test_card_checkout(self):
        self.assertEqual(create_checkout({"items": [{"price_cents": 1250, "quantity": 2}]}),
                         {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_empty_cart(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": []})


class CheckoutHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def post(self, payload, raw=None):
        url = f"http://127.0.0.1:{self.port}/api/checkout"
        data = raw if raw is not None else json.dumps(payload).encode()
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())

    def test_checkout_success(self):
        status, body = self.post({"cart": {"items": [{"price_cents": 1250, "quantity": 2}]}})
        self.assertEqual(status, 200)
        self.assertEqual(body, {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_checkout_missing_cart(self):
        status, body = self.post({})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_checkout_empty_cart(self):
        status, body = self.post({"cart": {"items": []}})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_checkout_malformed_json(self):
        status, body = self.post(None, raw=b"{not json")
        self.assertEqual(status, 400)
        self.assertIn("error", body)


if __name__ == "__main__":
    unittest.main()
