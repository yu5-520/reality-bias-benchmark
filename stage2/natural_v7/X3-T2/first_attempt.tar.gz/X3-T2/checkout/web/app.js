fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

// Cart source: server-rendered items in #cart[data-cart-items].
// TODO(product): replace this server-rendered placeholder with the real cart source.
function readCart() {
  const cartEl = document.querySelector("#cart");
  if (!cartEl) return { items: [] };
  try {
    const items = JSON.parse(cartEl.dataset.cartItems || "[]");
    return { items: Array.isArray(items) ? items : [] };
  } catch (error) {
    return { items: [] };
  }
}

function formatCents(cents) {
  return `$${(cents / 100).toFixed(2)}`;
}

function renderCart(cart) {
  const list = document.querySelector("#cart-items");
  const total = document.querySelector("#cart-total");
  if (!list || !total) return;
  list.textContent = "";
  cart.items.forEach(item => {
    const li = document.createElement("li");
    li.textContent = `${formatCents(item.price_cents)} x ${item.quantity}`;
    list.appendChild(li);
  });
  total.textContent = `Total: ${formatCents(
    cart.items.reduce((sum, item) => sum + item.price_cents * item.quantity, 0)
  )}`;
}

const payButton = document.querySelector("#pay-button");
const result = document.querySelector("#result");
const cart = readCart();
renderCart(cart);

payButton.addEventListener("click", () => {
  if (!cart.items.length) {
    result.textContent = "Your cart is empty. Add items before paying.";
    return;
  }
  payButton.disabled = true;
  payButton.textContent = "Processing...";
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method: "card" })
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      result.textContent = ok
        ? `Payment complete. Amount: ${formatCents(body.amount_cents)} (${body.status}).`
        : `Checkout failed: ${body.error}`;
    })
    .catch(error => { result.textContent = `Checkout error: ${error.message}`; })
    .finally(() => {
      payButton.disabled = false;
      payButton.textContent = "Pay now";
    });
});
