fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

document.querySelector("#pay-button").addEventListener("click", () => {
  const result = document.querySelector("#result");
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      cart: { items: [{ price_cents: 1999, quantity: 1 }] },
      method: "card"
    })
  })
    .then(response => response.json().then(data => ({ ok: response.ok, data })))
    .then(({ ok, data }) => {
      if (ok) {
        result.textContent = `Payment ${data.status}: ${data.amount_cents} cents via ${data.method}`;
      } else {
        result.textContent = `Error: ${data.error}`;
      }
    })
    .catch(error => { result.textContent = `Error: ${error.message}`; });
});
