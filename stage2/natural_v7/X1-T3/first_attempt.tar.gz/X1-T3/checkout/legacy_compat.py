"""Removed: the v1 compatibility HTTP path was retired with the v2.0 upgrade.

The current service entry point is `checkout_app.server` (see `run.py`).
"""
