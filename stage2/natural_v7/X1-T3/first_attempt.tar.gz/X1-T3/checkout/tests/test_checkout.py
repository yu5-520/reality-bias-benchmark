import unittest
from checkout_app.checkout import create_checkout
from checkout_app.server import main as current_main
import run


class CheckoutTests(unittest.TestCase):
    def test_card_checkout(self):
        self.assertEqual(create_checkout({"items": [{"price_cents": 1250, "quantity": 2}]}),
                         {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_empty_cart(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": []})


class LauncherTests(unittest.TestCase):
    def test_launcher_runs_current_service(self):
        # Regression guard: run.py must dispatch directly to the v2.0 service,
        # not to any retired compatibility path.
        self.assertIs(run.main, current_main)


if __name__ == "__main__":
    unittest.main()
