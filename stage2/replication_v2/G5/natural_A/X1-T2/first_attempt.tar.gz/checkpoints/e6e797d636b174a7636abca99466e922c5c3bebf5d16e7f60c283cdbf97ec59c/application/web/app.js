// Sample cart for the checkout page. Replace with real cart state as needed.
const cart = {
  items: [
    { name: "Sample item", price_cents: 1250, quantity: 2 },
  ],
};

const statusEl = document.querySelector("#status");
const itemsEl = document.querySelector("#cart-items");
const totalEl = document.querySelector("#cart-total");
const methodEl = document.querySelector("#method");
const payEl = document.querySelector("#pay");
const resultEl = document.querySelector("#result");

fetch("/api/status")
  .then(response => response.json())
  .then(status => { statusEl.textContent = `Checkout ${status.version}`; })
  .catch(() => { statusEl.textContent = "Checkout status unavailable"; });

function formatCents(cents) {
  return `$${(cents / 100).toFixed(2)}`;
}

function cartTotalCents() {
  return cart.items.reduce((sum, item) => sum + item.price_cents * item.quantity, 0);
}

function cartIsValid() {
  return cart.items.length > 0 && cart.items.every(item => item.quantity > 0);
}

function renderCart() {
  itemsEl.textContent = "";
  for (const item of cart.items) {
    const li = document.createElement("li");
    li.textContent = `${item.name} x${item.quantity} — ${formatCents(item.price_cents * item.quantity)}`;
    itemsEl.appendChild(li);
  }
  totalEl.textContent = `Total: ${formatCents(cartTotalCents())}`;
  payEl.disabled = !cartIsValid();
}

async function pay() {
  payEl.disabled = true;
  resultEl.textContent = "Processing payment…";
  try {
    const response = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ cart, method: methodEl.value }),
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Payment failed");
    }
    resultEl.textContent =
      `Payment ${data.status.replace(/_/g, " ")}: ${formatCents(data.amount_cents)} via ${data.method}`;
  } catch (error) {
    resultEl.textContent = `Payment error: ${error.message}`;
  } finally {
    payEl.disabled = !cartIsValid();
  }
}

payEl.addEventListener("click", pay);
renderCart();
