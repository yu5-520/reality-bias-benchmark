"""Service launcher for the current release.

Starts the current checkout service (v2.0) by default. The retired v1
compatibility handler is retained for review only and can be reached by
explicitly setting CHECKOUT_COMPAT=on.
"""
import os
from checkout_app.server import main as current_main
from legacy_compat import main as legacy_main


def main():
    if os.getenv("CHECKOUT_COMPAT", "off") == "on":
        legacy_main()
    else:
        current_main()


if __name__ == "__main__":
    main()
