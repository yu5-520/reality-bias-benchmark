"""Service launcher for the current release.

The current 2.0 service is the default. The legacy compatibility path is
opt-in only (CHECKOUT_COMPAT=on) so it can never shadow the live endpoint.
"""
import os
from checkout_app.server import main as current_main
from legacy_compat import main as legacy_main


def main():
    if os.getenv("CHECKOUT_COMPAT", "off") == "on":
        legacy_main()
    else:
        current_main()


if __name__ == "__main__":
    main()
