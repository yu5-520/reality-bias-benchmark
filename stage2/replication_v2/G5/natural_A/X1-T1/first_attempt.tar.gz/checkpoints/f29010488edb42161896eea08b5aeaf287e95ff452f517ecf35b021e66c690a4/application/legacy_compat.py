"""Old v1 HTTP path, retained temporarily across the upgrade.

Listens on 8082 so it can never collide with or shadow the current 2.0
service on 8080. Opt in with CHECKOUT_COMPAT=on.
"""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class LegacyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/status":
            return self.reply(200, {"service": "checkout", "version": "1.9", "compat": True})
        self.reply(404, {"error": "Not found"})

    def do_POST(self):
        if self.path != "/api/checkout":
            return self.reply(404, {"error": "Not found"})
        self.reply(410, {"error": "Legacy checkout retired"})

    def reply(self, status, value):
        body = json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main():
    ThreadingHTTPServer(("127.0.0.1", 8082), LegacyHandler).serve_forever()


if __name__ == "__main__":
    main()
