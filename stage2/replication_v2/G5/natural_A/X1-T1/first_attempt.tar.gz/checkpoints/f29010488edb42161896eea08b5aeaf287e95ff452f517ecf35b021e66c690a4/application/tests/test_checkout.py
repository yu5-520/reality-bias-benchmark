import json
import os
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from checkout_app.checkout import create_checkout


class CheckoutTests(unittest.TestCase):
    def test_card_checkout(self):
        self.assertEqual(create_checkout({"items": [{"price_cents": 1250, "quantity": 2}]}),
                         {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_empty_cart(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": []})

    def test_bank_transfer(self):
        self.assertEqual(
            create_checkout({"items": [{"price_cents": 500, "quantity": 3}]}, "bank_transfer"),
            {"status": "pending_payment", "amount_cents": 1500, "method": "bank_transfer"})

    def test_non_positive_quantity(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": [{"price_cents": 100, "quantity": 0}]})

    def test_unsupported_method(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": [{"price_cents": 100, "quantity": 1}]}, "cash")


class _ServerFixture:
    """Start a handler on an ephemeral port for the duration of a test."""

    def __init__(self, handler_cls):
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
        self.port = self._server.server_address[1]
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)

    def __enter__(self):
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._server.shutdown()
        self._server.server_close()
        self._thread.join()

    def get(self, path):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{self.port}{path}") as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())

    def post(self, path, body):
        data = json.dumps(body).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}", data=data,
            headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())


class ServerTests(unittest.TestCase):
    def test_status_reports_current_version(self):
        from checkout_app.server import Handler
        with _ServerFixture(Handler) as srv:
            status, body = srv.get("/api/status")
        self.assertEqual(status, 200)
        self.assertEqual(body["version"], "2.0")

    def test_checkout_success(self):
        from checkout_app.server import Handler
        with _ServerFixture(Handler) as srv:
            status, body = srv.post("/api/checkout",
                                    {"cart": {"items": [{"price_cents": 100, "quantity": 2}]}})
        self.assertEqual(status, 200)
        self.assertEqual(body["amount_cents"], 200)

    def test_checkout_rejects_oversized_body(self):
        from checkout_app.server import Handler
        with _ServerFixture(Handler) as srv:
            status, body = srv.post("/api/checkout", {"cart": {"items": []}, "pad": "x" * 70000})
        self.assertEqual(status, 400)


class LegacyCompatTests(unittest.TestCase):
    def test_legacy_post_is_gone(self):
        from legacy_compat import LegacyHandler
        with _ServerFixture(LegacyHandler) as srv:
            status, body = srv.post("/api/checkout", {"cart": {"items": []}})
        self.assertEqual(status, 410)

    def test_legacy_status_available(self):
        from legacy_compat import LegacyHandler
        with _ServerFixture(LegacyHandler) as srv:
            status, body = srv.get("/api/status")
        self.assertEqual(status, 200)
        self.assertTrue(body.get("compat"))


class LauncherTests(unittest.TestCase):
    def test_compat_off_by_default(self):
        import run
        started = {}
        run.current_main = lambda: started.setdefault("current", True)
        run.legacy_main = lambda: started.setdefault("legacy", True)
        os.environ.pop("CHECKOUT_COMPAT", None)
        run.main()
        self.assertTrue(started.get("current"))
        self.assertNotIn("legacy", started)

    def test_compat_opt_in(self):
        import run
        started = {}
        run.current_main = lambda: started.setdefault("current", True)
        run.legacy_main = lambda: started.setdefault("legacy", True)
        os.environ["CHECKOUT_COMPAT"] = "on"
        try:
            run.main()
        finally:
            os.environ.pop("CHECKOUT_COMPAT", None)
        self.assertTrue(started.get("legacy"))
        self.assertNotIn("current", started)


if __name__ == "__main__":
    unittest.main()
