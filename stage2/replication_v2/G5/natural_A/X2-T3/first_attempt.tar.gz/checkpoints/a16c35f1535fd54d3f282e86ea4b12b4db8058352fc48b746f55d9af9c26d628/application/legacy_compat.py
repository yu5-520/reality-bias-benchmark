"""Legacy v1 HTTP path removed as of the current release."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class LegacyHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        self.send_response(410)
        self.end_headers()
        self.wfile.write(b"Legacy checkout retired")


def main():
    ThreadingHTTPServer(("127.0.0.1", 8080), LegacyHandler).serve_forever()
