"""Service launcher for the current checkout release."""
from checkout_app.server import main


if __name__ == "__main__":
    main()
