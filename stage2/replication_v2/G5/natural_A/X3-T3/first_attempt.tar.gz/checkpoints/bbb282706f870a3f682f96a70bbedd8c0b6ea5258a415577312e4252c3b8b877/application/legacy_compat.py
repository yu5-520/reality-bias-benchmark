"""Deprecated v1 compatibility path removed after the v2.0 upgrade.

The retired v1 HTTP handler previously bound 127.0.0.1:8080, conflicting with
the current checkout service. It has been deleted from the launch path and
neutralized here so it can no longer shadow the current service.

The current entry point is checkout_app.server:main (launched via run.py).
"""
