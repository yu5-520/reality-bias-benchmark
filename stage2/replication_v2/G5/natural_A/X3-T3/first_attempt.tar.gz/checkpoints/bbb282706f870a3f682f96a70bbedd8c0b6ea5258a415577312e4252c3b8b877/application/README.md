# Checkout sample

This small service exposes `GET /api/status` and `POST /api/checkout` on port 8080.
Start it with `python run.py` (or `python -m checkout_app.server`), then open
`web/index.html` through the same server. Run `python -m unittest discover -s tests`
to check the API.

`versions/before.json` and `versions/after.json` identify the upgrade; the
prior service snapshot is runnable via `python versions/before/server.py` on
port 8081 for comparison only. The current executable path is `run.py`, which
launches `checkout_app.server:main` directly; the retired v1 compatibility path
has been removed.
