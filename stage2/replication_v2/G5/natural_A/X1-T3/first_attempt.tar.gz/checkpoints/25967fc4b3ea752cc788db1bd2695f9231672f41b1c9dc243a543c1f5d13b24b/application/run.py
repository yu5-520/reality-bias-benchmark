"""Service launcher for the current release."""
from checkout_app.server import main


if __name__ == "__main__":
    main()
