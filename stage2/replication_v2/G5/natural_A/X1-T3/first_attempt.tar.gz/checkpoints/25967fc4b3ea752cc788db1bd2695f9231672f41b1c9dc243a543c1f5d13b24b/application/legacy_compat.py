"""Removed: the v1 compatibility HTTP path was retired with the 2.0 upgrade.

This module is intentionally empty. The current service is launched via
`python -m checkout_app.server` (or `python run.py`).
"""
