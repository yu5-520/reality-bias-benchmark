fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const CART = { items: [{ price_cents: 2500, quantity: 1 }] };

function formatAmount(cents) {
  return `$${(cents / 100).toFixed(2)}`;
}

function pay() {
  const button = document.querySelector("#pay");
  const result = document.querySelector("#result");
  const method = document.querySelector("#method").value;
  button.disabled = true;
  result.textContent = "Processing payment\u2026";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: CART, method }),
  })
    .then(response => response.json().then(data => ({ ok: response.ok, data })))
    .then(({ ok, data }) => {
      if (!ok) throw new Error(data.error || "Checkout failed");
      result.textContent = `Payment ${data.status}: ${formatAmount(data.amount_cents)} via ${data.method}`;
    })
    .catch(error => { result.textContent = `Error: ${error.message}`; })
    .finally(() => { button.disabled = false; });
}

document.querySelector("#pay").addEventListener("click", pay);
