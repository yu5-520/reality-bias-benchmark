fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const payButton = document.querySelector("#pay-button");
const result = document.querySelector("#result");

payButton.addEventListener("click", async () => {
  payButton.disabled = true;
  result.textContent = "Processing payment...";
  try {
    const response = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        cart: { items: [{ price_cents: 1250, quantity: 2 }] },
        method: "card",
      }),
    });
    const data = await response.json();
    if (!response.ok) {
      result.textContent = data.error;
      return;
    }
    result.textContent = `Payment ${data.status} for ${data.amount_cents} cents via ${data.method}`;
  } catch (error) {
    result.textContent = error.message;
  } finally {
    payButton.disabled = false;
  }
});
