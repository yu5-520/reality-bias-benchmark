"""HTTP-level and static-wiring tests for the payment button checkout flow."""
import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from checkout_app.server import Handler, DEMO_CART

WEB_ROOT = Path(__file__).resolve().parent.parent / "web"


class ServerTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def url(self, path):
        return f"http://127.0.0.1:{self.port}{path}"

    def get(self, path):
        with urllib.request.urlopen(self.url(path)) as resp:
            return resp.status, resp.read(), resp.headers

    def post(self, path, payload):
        data = json.dumps(payload).encode()
        req = urllib.request.Request(self.url(path), data=data,
                                     headers={"Content-Type": "application/json"},
                                     method="POST")
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())


class StaticWiringTests(ServerTestCase):
    def test_index_served_with_form_elements(self):
        status, body, headers = self.get("/")
        self.assertEqual(status, 200)
        self.assertIn("text/html", headers.get("Content-Type", ""))
        html = body.decode()
        self.assertIn('id="method"', html)
        self.assertIn('id="pay-button"', html)
        self.assertIn('id="result"', html)
        self.assertIn('aria-live="polite"', html)
        self.assertIn('id="checkout-form"', html)

    def test_app_js_served_and_wires_checkout(self):
        status, body, headers = self.get("/app.js")
        self.assertEqual(status, 200)
        self.assertIn("javascript", headers.get("Content-Type", ""))
        js = body.decode()
        self.assertIn("/api/checkout", js)
        self.assertIn("/api/cart", js)
        self.assertIn("#pay-button", js)
        self.assertIn("#result", js)
        self.assertIn('"POST"', js)
        self.assertIn("disabled = true", js)
        self.assertIn("disabled = false", js)
        self.assertIn("finally", js)

    def test_app_js_no_longer_uses_hardcoded_demo_cart(self):
        js = (WEB_ROOT / "app.js").read_text()
        self.assertNotIn("DEMO_CART", js)
        self.assertIn("cartPromise", js)


class CartApiTests(ServerTestCase):
    def test_get_cart_returns_positive_quantity_items(self):
        status, body, headers = self.get("/api/cart")
        self.assertEqual(status, 200)
        self.assertIn("application/json", headers.get("Content-Type", ""))
        cart = json.loads(body)
        self.assertEqual(cart, DEMO_CART)
        self.assertTrue(cart["items"])
        self.assertTrue(all(i["quantity"] >= 1 for i in cart["items"]))
        self.assertTrue(all(i["price_cents"] > 0 for i in cart["items"]))

    def test_cart_satisfies_create_checkout_rule(self):
        status, body, _ = self.get("/api/cart")
        self.assertEqual(status, 200)
        cart = json.loads(body)
        status, checkout = self.post("/api/checkout", {"cart": cart, "method": "card"})
        self.assertEqual(status, 200)
        self.assertEqual(checkout["status"], "pending_payment")


class CheckoutApiTests(ServerTestCase):
    def test_status(self):
        status, body, _ = self.get("/api/status")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["version"], "2.0")

    def test_checkout_success_renders_amount(self):
        cart = {"items": [{"price_cents": 1999, "quantity": 1}]}
        status, body = self.post("/api/checkout", {"cart": cart, "method": "card"})
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "pending_payment")
        self.assertEqual(body["amount_cents"], 1999)
        self.assertEqual(body["method"], "card")
        self.assertEqual(f"{body['amount_cents'] / 100:.2f}", "19.99")

    def test_checkout_bank_transfer(self):
        cart = {"items": [{"price_cents": 500, "quantity": 2}]}
        status, body = self.post("/api/checkout", {"cart": cart, "method": "bank_transfer"})
        self.assertEqual(status, 200)
        self.assertEqual(body["amount_cents"], 1000)
        self.assertEqual(body["method"], "bank_transfer")

    def test_empty_cart_returns_400_with_error(self):
        status, body = self.post("/api/checkout", {"cart": {"items": []}, "method": "card"})
        self.assertEqual(status, 400)
        self.assertIn("error", body)
        self.assertTrue(body["error"])

    def test_zero_quantity_returns_400(self):
        cart = {"items": [{"price_cents": 1999, "quantity": 0}]}
        status, body = self.post("/api/checkout", {"cart": cart, "method": "card"})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_unsupported_method_returns_400(self):
        cart = {"items": [{"price_cents": 1999, "quantity": 1}]}
        status, body = self.post("/api/checkout", {"cart": cart, "method": "crypto"})
        self.assertEqual(status, 400)
        self.assertIn("Unsupported payment method", body["error"])

    def test_missing_cart_returns_400(self):
        status, body = self.post("/api/checkout", {"method": "card"})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_unknown_path_returns_404(self):
        status, body = self.post("/api/nope", {})
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main()
