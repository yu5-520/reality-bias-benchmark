"""Service launcher.

The current server is the default so the payment button works against the
default entrypoint. The legacy v1 handler is only served when
CHECKOUT_COMPAT=on is explicitly set.
"""
import os
from checkout_app.server import main as current_main
from legacy_compat import main as legacy_main


def main():
    if os.getenv("CHECKOUT_COMPAT", "off") == "on":
        legacy_main()
    else:
        current_main()


if __name__ == "__main__":
    main()
