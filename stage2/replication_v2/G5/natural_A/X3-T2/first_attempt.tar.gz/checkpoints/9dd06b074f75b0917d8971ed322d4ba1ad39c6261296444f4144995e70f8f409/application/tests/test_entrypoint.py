"""Entrypoint behavior: run.py selects current_main by default.

The current server is the default so the payment button works against the
default entrypoint. The legacy v1 handler (410 on POST /api/checkout) is only
served when CHECKOUT_COMPAT=on is explicitly set.
"""
import os
import unittest
from unittest import mock

import run


class EntrypointTests(unittest.TestCase):
    def test_default_env_selects_current(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("CHECKOUT_COMPAT", None)
            with mock.patch("run.legacy_main") as legacy, mock.patch("run.current_main") as current:
                run.main()
                current.assert_called_once()
                legacy.assert_not_called()

    def test_compat_on_selects_legacy(self):
        with mock.patch.dict(os.environ, {"CHECKOUT_COMPAT": "on"}):
            with mock.patch("run.legacy_main") as legacy, mock.patch("run.current_main") as current:
                run.main()
                legacy.assert_called_once()
                current.assert_not_called()

    def test_compat_off_selects_current(self):
        with mock.patch.dict(os.environ, {"CHECKOUT_COMPAT": "off"}):
            with mock.patch("run.legacy_main") as legacy, mock.patch("run.current_main") as current:
                run.main()
                current.assert_called_once()
                legacy.assert_not_called()


if __name__ == "__main__":
    unittest.main()
