fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

// Cart is loaded from the server so the page no longer relies on a placeholder.
let cartPromise = fetch("/api/cart")
  .then(response => {
    if (!response.ok) {
      throw new Error("Could not load cart");
    }
    return response.json();
  });

const form = document.querySelector("#checkout-form");
const result = document.querySelector("#result");
const payButton = document.querySelector("#pay-button");

form.addEventListener("submit", event => {
  event.preventDefault();
  const method = document.querySelector("#method").value;
  payButton.disabled = true;
  result.textContent = "Processing payment...";
  cartPromise
    .then(cart =>
      fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cart, method }),
      })
    )
    .then(response =>
      response.json().then(data => {
        if (!response.ok) {
          throw new Error(data.error || "Payment failed");
        }
        return data;
      })
    )
    .then(data => {
      const amount = (data.amount_cents / 100).toFixed(2);
      result.textContent = `Payment ${data.status}: $${amount} via ${data.method}`;
    })
    .catch(error => { result.textContent = `Payment failed: ${error.message}`; })
    .finally(() => { payButton.disabled = false; });
});
