"""Retired legacy v1 HTTP path. Removed as part of the v2 upgrade.

This module previously served the 410 'Legacy checkout retired' handler on
port 8080. It is intentionally empty and must not be imported; the current
entry point is 'python -m checkout_app.server'.
"""
