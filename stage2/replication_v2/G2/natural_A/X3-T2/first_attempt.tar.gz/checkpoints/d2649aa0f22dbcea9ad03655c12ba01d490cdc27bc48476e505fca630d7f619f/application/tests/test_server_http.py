"""Server-level HTTP tests covering the documented launch path.

These exercise POST /api/checkout over real HTTP against the current app
(checkout_app.server), which is what run.py now routes to by default.
"""
import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from checkout_app.server import Handler


class ServerHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=5)

    def post(self, payload):
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/api/checkout",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())

    def test_valid_card_cart_returns_pending_payment(self):
        status, body = self.post({"cart": {"items": [{"price_cents": 1250, "quantity": 2}]}, "method": "card"})
        self.assertEqual(status, 200)
        self.assertEqual(body, {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_empty_cart_returns_400(self):
        status, body = self.post({"cart": {"items": []}, "method": "card"})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_unsupported_method_returns_400(self):
        status, body = self.post({"cart": {"items": [{"price_cents": 100, "quantity": 1}]}, "method": "crypto"})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_status_endpoint(self):
        with urllib.request.urlopen(f"http://127.0.0.1:{self.port}/api/status") as resp:
            self.assertEqual(resp.status, 200)
            self.assertEqual(json.loads(resp.read())["version"], "2.0")


if __name__ == "__main__":
    unittest.main()
