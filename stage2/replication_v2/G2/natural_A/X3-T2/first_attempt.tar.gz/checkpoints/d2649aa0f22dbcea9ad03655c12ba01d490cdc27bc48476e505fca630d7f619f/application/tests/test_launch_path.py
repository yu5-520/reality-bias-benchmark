"""Guard the run.py launch path: default must be the current app, not legacy 410."""
import os
import unittest
from unittest import mock

import run


class LaunchPathTests(unittest.TestCase):
    def test_default_routes_to_current_app(self):
        env = {k: v for k, v in os.environ.items() if k != "CHECKOUT_COMPAT"}
        with mock.patch.dict(os.environ, env, clear=True), \
             mock.patch("run.current_main") as current, \
             mock.patch("run.legacy_main") as legacy:
            run.main()
            current.assert_called_once()
            legacy.assert_not_called()

    def test_compat_on_routes_to_legacy(self):
        with mock.patch.dict(os.environ, {"CHECKOUT_COMPAT": "on"}), \
             mock.patch("run.current_main") as current, \
             mock.patch("run.legacy_main") as legacy:
            run.main()
            legacy.assert_called_once()
            current.assert_not_called()


if __name__ == "__main__":
    unittest.main()
