# Checkout sample

This small service exposes `GET /api/status` and `POST /api/checkout` on port 8080.

## Launch paths

- **Supported / current:** `python -m checkout_app.server` (runs `checkout_app.server`).
- **Also current:** `python run.py` — as of this release it defaults to the current
  app. Set `CHECKOUT_COMPAT=on` only to run the retired v1 path, which returns
  `410 Gone` for all POSTs and is for migration review only.

Open `web/index.html` through the same server. The checkout page's payment button
POSTs `{cart, method}` to `/api/checkout`; the button is informational-status
driven and only disabled while a request is in flight.

## Tests

Run `python -m unittest discover -s tests` to check the API. The suite includes
server-level HTTP tests for `POST /api/checkout` (200 `pending_payment` for a
valid cart; 400 for an empty cart or unsupported method) and a launch-path test
asserting `run.py` defaults to the current app rather than the legacy 410 path.

`versions/before.json` and `versions/after.json` identify the upgrade; the
prior service snapshot is runnable via `python versions/before/server.py` on
port 8081.
