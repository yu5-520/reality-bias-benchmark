const payButton = document.querySelector("#pay");
const result = document.querySelector("#result");

// Cart used by the existing checkout flow. Replace with the real cart source when available.
let cart = { items: [{ price_cents: 1250, quantity: 2 }] };

function setBusy(busy) {
  payButton.disabled = busy;
  payButton.textContent = busy ? "Processing..." : "Pay now";
}

// Button is enabled by default; /api/status is informational only and never gates payment.
setBusy(false);

fetch("/api/status")
  .then(response => response.json())
  .then(status => {
    document.querySelector("#status").textContent = `Checkout ${status.version}`;
  })
  .catch(() => {
    document.querySelector("#status").textContent = "Checkout status unavailable";
  });

payButton.addEventListener("click", () => {
  setBusy(true);
  result.textContent = "";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method: "card" })
  })
    .then(async response => {
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Checkout failed");
      }
      return data;
    })
    .then(data => {
      const amount = (data.amount_cents / 100).toFixed(2);
      result.textContent = `Payment pending: ${data.status} for $${amount} via ${data.method}`;
    })
    .catch(error => {
      result.textContent = `Error: ${error.message}`;
    })
    .finally(() => setBusy(false));
});
