fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const form = document.querySelector("#checkout-form");
const result = document.querySelector("#result");
const payButton = document.querySelector("#pay-button");

function loadCart() {
  const raw = window.localStorage.getItem("cart");
  if (!raw) return { items: [] };
  try {
    return JSON.parse(raw);
  } catch (err) {
    return { items: [] };
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const method = document.querySelector("#method").value;
  payButton.disabled = true;
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: loadCart(), method }),
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      if (!ok) throw new Error(body.error || "Checkout failed");
      result.textContent = `Payment ${body.status}: ${body.amount_cents} cents via ${body.method}`;
    })
    .catch(err => { result.textContent = `Error: ${err.message}`; })
    .finally(() => { payButton.disabled = false; });
});
