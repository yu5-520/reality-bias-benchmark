"""Regression tests: the launcher must use only the current server entry point."""
import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUN_PY = ROOT / "run.py"
LEGACY = ROOT / "legacy_compat.py"


class LauncherTests(unittest.TestCase):
    def test_run_py_has_no_legacy_references(self):
        source = RUN_PY.read_text()
        self.assertNotIn("legacy_compat", source)
        self.assertNotIn("legacy_main", source)
        self.assertNotIn("CHECKOUT_COMPAT", source)

    def test_run_py_calls_current_main(self):
        tree = ast.parse(RUN_PY.read_text())
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                imported.add(node.module)
        self.assertEqual(imported, {"checkout_app.server"})

    def test_legacy_path_cannot_interfere(self):
        # The legacy compatibility path must not be importable or start a server.
        if not LEGACY.exists():
            return
        with self.assertRaises(ImportError):
            import legacy_compat  # noqa: F401


if __name__ == "__main__":
    unittest.main()
