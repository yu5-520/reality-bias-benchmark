"""Removed in the v2.0 upgrade. Kept only as a hard-fail stub.

The legacy v1 HTTP path (port 8080, returns 410) is retired. Any attempt to
import this module fails immediately so the old compatibility path can never
interfere with checkout. Use checkout_app.server instead.
"""

raise ImportError(
    "legacy_compat was removed in the v2.0 upgrade; use checkout_app.server instead"
)
