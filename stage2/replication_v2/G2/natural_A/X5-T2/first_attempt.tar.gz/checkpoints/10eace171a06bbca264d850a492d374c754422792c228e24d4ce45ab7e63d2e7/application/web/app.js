fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const payButton = document.querySelector("#pay");
const result = document.querySelector("#result");
const methodSelect = document.querySelector("#method");

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  result.textContent = "Processing payment\u2026";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      cart: { items: [{ price_cents: 1000, quantity: 1 }] },
      method: methodSelect.value
    })
  })
    .then(response => response.text().then(text => {
      let body = null;
      try { body = JSON.parse(text); } catch (e) { body = null; }
      return { ok: response.ok, body, text };
    }))
    .then(({ ok, body, text }) => {
      if (!ok) {
        throw new Error((body && body.error) || text || "Checkout failed");
      }
      result.textContent = `Payment ${body.status}: ${body.amount_cents} cents via ${body.method}`;
    })
    .catch(err => { result.textContent = `Error: ${err.message}`; })
    .finally(() => { payButton.disabled = false; });
});
