fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const payButton = document.querySelector("#pay");
const result = document.querySelector("#result");

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  result.textContent = "Processing payment\u2026";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      cart: { items: [{ price_cents: 1000, quantity: 1 }] },
      method: "card"
    })
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      if (!ok) {
        throw new Error(body.error || "Checkout failed");
      }
      result.textContent = `Payment ${body.status}: ${body.amount_cents} cents via ${body.method}`;
    })
    .catch(err => { result.textContent = `Error: ${err.message}`; })
    .finally(() => { payButton.disabled = false; });
});
