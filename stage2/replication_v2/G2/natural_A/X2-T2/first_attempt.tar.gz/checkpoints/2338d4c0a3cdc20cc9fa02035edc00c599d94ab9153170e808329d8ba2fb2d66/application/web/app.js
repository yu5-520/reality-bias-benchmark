fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const cart = { items: [{ price_cents: 1250, quantity: 2 }] };

const payButton = document.querySelector("#pay-button");
const result = document.querySelector("#result");

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method: "card" })
  })
    .then(response => response.json().then(data => ({ ok: response.ok, data })))
    .then(({ ok, data }) => {
      if (!ok) {
        result.textContent = `Payment failed: ${data.error}`;
        return;
      }
      const amount = (data.amount_cents / 100).toFixed(2);
      result.textContent = `Payment ${data.status} for $${amount} via ${data.method}`;
    })
    .catch(() => { result.textContent = "Payment failed: network error"; })
    .finally(() => { payButton.disabled = false; });
});
