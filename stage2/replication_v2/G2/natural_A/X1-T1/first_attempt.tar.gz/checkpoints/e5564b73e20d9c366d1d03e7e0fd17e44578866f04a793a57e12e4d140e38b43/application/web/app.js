const statusEl = document.querySelector("#status");
const resultEl = document.querySelector("#result");
const form = document.querySelector("#checkout-form");

fetch("/api/status")
  .then(response => response.json())
  .then(status => { statusEl.textContent = `Checkout ${status.version}`; })
  .catch(() => { statusEl.textContent = "Checkout status unavailable"; });

form.addEventListener("submit", event => {
  event.preventDefault();
  const price = Number(document.querySelector("#price").value);
  const quantity = Number(document.querySelector("#quantity").value);
  const method = document.querySelector("#method").value;

  resultEl.textContent = "Submitting...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      cart: { items: [{ price_cents: price, quantity: quantity }] },
      method: method
    })
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      if (!ok) {
        resultEl.textContent = `Error: ${body.error}`;
        return;
      }
      resultEl.textContent =
        `Status ${body.status}: ${body.amount_cents} cents via ${body.method}`;
    })
    .catch(() => { resultEl.textContent = "Error: checkout request failed"; });
});
