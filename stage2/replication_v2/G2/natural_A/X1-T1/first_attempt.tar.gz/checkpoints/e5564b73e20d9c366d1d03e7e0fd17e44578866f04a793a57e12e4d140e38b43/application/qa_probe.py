"""Launcher routing probe: verifies run.py selects the v2 service by default.

Does not bind a socket; it monkeypatches the two entry points and inspects which
one run.main() dispatches to under different CHECKOUT_COMPAT settings.
"""
import os
import run

calls = []
run.current_main = lambda: calls.append("current")
run.legacy_main = lambda: calls.append("legacy")

os.environ.pop("CHECKOUT_COMPAT", None)
run.main()
assert calls == ["current"], calls

calls.clear()
os.environ["CHECKOUT_COMPAT"] = "on"
run.main()
assert calls == ["legacy"], calls

calls.clear()
os.environ["CHECKOUT_COMPAT"] = "off"
run.main()
assert calls == ["current"], calls

print("launcher routing OK")
