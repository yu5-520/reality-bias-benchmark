"""Service launcher for the current release.

Serves the v2.0 checkout service by default. The legacy compatibility path is
still present for review but is now opt-in: set CHECKOUT_COMPAT=on to run it.
"""
import os
from checkout_app.server import main as current_main
from legacy_compat import main as legacy_main


def main():
    if os.getenv("CHECKOUT_COMPAT", "off") == "on":
        legacy_main()
    else:
        current_main()


if __name__ == "__main__":
    main()
