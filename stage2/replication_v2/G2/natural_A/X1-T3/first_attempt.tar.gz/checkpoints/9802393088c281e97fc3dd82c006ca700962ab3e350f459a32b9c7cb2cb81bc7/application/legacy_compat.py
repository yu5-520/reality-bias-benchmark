"""Removed: the v1 compatibility HTTP path was retired in the 2.0 upgrade.

The current service is launched via ``python -m checkout_app.server`` (or
``python run.py``). The prior snapshot remains available for comparison at
``versions/before/server.py`` on port 8081.
"""
