"""Legacy v1 HTTP path removed after the v2 upgrade.

The old module is intentionally left without a server implementation so that
any stale imports fail fast instead of silently binding port 8080 and
interfering with the current checkout service.
"""


def main():
    raise RuntimeError(
        "legacy_compat has been retired; use checkout_app.server:main instead"
    )
