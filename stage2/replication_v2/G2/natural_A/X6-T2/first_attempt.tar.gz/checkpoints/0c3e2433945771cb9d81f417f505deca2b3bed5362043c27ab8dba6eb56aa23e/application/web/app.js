fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const cart = {
  items: [
    { name: "Example item", price_cents: 1200, quantity: 1 }
  ]
};

document.querySelector("#pay-button").addEventListener("click", () => {
  const result = document.querySelector("#result");
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method: "card" })
  })
    .then(response => response.json().then(data => ({ ok: response.ok, data })))
    .then(({ ok, data }) => {
      if (!ok) {
        throw new Error(data && data.error ? data.error : "Checkout failed");
      }
      const amount = (data.amount_cents / 100).toFixed(2);
      result.textContent = `Payment ${data.status}: $${amount} via ${data.method}`;
    })
    .catch(error => {
      result.textContent = `Error: ${error.message}`;
    });
});
