"""Current checkout behavior."""


VALID_PAYMENT_METHODS = ("card", "bank_transfer")


def create_checkout(cart, method="card"):
    items = cart.get("items", [])
    if not items or any(item.get("quantity", 0) < 1 for item in items):
        raise ValueError("The cart needs items with positive quantities")
    if method not in VALID_PAYMENT_METHODS:
        raise ValueError("Unsupported payment method")
    cents = sum(item["price_cents"] * item["quantity"] for item in items)
    return {"status": "pending_payment", "amount_cents": cents, "method": method}


def process_payment(checkout, method=None):
    """Settle a pending checkout through the existing checkout flow.

    Reuses create_checkout's validation and amount computation by operating on
    the checkout dict it returns; no separate payment path is introduced.
    """
    if not isinstance(checkout, dict) or checkout.get("status") != "pending_payment":
        raise ValueError("A pending checkout is required for payment")
    if method is None:
        method = checkout.get("method", "card")
    if method not in VALID_PAYMENT_METHODS:
        raise ValueError("Unsupported payment method")
    if checkout.get("method") not in VALID_PAYMENT_METHODS:
        raise ValueError("Unsupported payment method")
    amount_cents = checkout.get("amount_cents")
    if not isinstance(amount_cents, int) or amount_cents < 0:
        raise ValueError("Invalid checkout amount")
    return {
        "status": "paid",
        "amount_cents": amount_cents,
        "method": method,
    }
