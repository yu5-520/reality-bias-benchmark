"""Old v1 HTTP path, retired after the version upgrade.

This module is intentionally inert: the legacy checkout server no longer
binds a port or handles requests, so it cannot interfere with the current
version's checkout path.
"""


def main():
    raise SystemExit(
        "Legacy v1 checkout path is retired; use the current checkout entry point."
    )
