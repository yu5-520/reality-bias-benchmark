fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const cart = { items: [{ price_cents: 1250, quantity: 2 }] };

document.querySelector("#pay-button").addEventListener("click", () => {
  const method = document.querySelector("#method").value;
  const result = document.querySelector("#result");
  result.textContent = "Processing payment\u2026";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method })
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      if (!ok) { throw new Error(body.error || "Checkout failed"); }
      const amount = (body.amount_cents / 100).toFixed(2);
      result.textContent = `Payment ${body.status}: ${amount} via ${body.method}`;
    })
    .catch(error => { result.textContent = `Error: ${error.message}`; });
});
