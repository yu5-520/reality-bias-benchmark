fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

document.querySelector("#pay").addEventListener("click", () => {
  const result = document.querySelector("#result");
  const cart = { items: [{ price_cents: 1250, quantity: 1 }] };
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method: "card" }),
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      if (!ok) throw new Error(body.error || "Checkout failed");
      result.textContent = `${body.status} ${body.amount_cents} (${body.method})`;
    })
    .catch(error => { result.textContent = `Error: ${error.message}`; });
});
