"""Old v1 HTTP path, retired after the version update."""
