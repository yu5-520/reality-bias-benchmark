"""Legacy v1 HTTP compatibility path removed after the version upgrade.

This module is intentionally inert: it no longer starts a server or binds a
port, so it cannot interfere with the current checkout application.
"""

__all__ = []
