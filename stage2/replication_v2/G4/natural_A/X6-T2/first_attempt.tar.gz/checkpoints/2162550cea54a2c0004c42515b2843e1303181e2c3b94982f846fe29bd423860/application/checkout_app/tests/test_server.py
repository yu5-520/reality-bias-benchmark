"""HTTP-level tests for the checkout server, exercised in-process."""
import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from checkout_app.server import Handler


class ServerTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        host, port = cls.server.server_address
        cls.base = f"http://{host}:{port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)

    def post(self, path, payload, raw=None):
        data = raw if raw is not None else json.dumps(payload).encode()
        req = urllib.request.Request(
            self.base + path, data=data, method="POST",
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())

    def get(self, path):
        try:
            with urllib.request.urlopen(self.base + path, timeout=5) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()

    def test_status_endpoint(self):
        status, body = self.get("/api/status")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body), {"service": "checkout", "version": "2.0"})

    def test_successful_card_checkout(self):
        status, body = self.post("/api/checkout", {
            "cart": {"items": [{"price_cents": 1000, "quantity": 1}]},
            "method": "card",
        })
        self.assertEqual(status, 200)
        self.assertEqual(body, {"status": "pending_payment", "amount_cents": 1000, "method": "card"})

    def test_default_method_is_card(self):
        status, body = self.post("/api/checkout", {
            "cart": {"items": [{"price_cents": 500, "quantity": 3}]},
        })
        self.assertEqual(status, 200)
        self.assertEqual(body["method"], "card")
        self.assertEqual(body["amount_cents"], 1500)

    def test_empty_cart_returns_400(self):
        status, body = self.post("/api/checkout", {"cart": {"items": []}})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_missing_cart_returns_400(self):
        status, body = self.post("/api/checkout", {})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_unsupported_method_returns_400(self):
        status, body = self.post("/api/checkout", {
            "cart": {"items": [{"price_cents": 100, "quantity": 1}]},
            "method": "crypto",
        })
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_malformed_json_returns_400(self):
        status, body = self.post("/api/checkout", None, raw=b"{not json")
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_unknown_route_returns_404(self):
        status, _ = self.post("/api/nope", {"cart": {"items": []}})
        self.assertEqual(status, 404)

    def test_serves_index_and_app_js(self):
        status, body = self.get("/")
        self.assertEqual(status, 200)
        self.assertIn(b"pay-button", body)
        status, body = self.get("/app.js")
        self.assertEqual(status, 200)
        self.assertIn(b"/api/checkout", body)


if __name__ == "__main__":
    unittest.main()
