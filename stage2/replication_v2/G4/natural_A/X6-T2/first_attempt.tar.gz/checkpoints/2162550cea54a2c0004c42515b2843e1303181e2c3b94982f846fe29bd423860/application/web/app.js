const payButton = document.querySelector("#pay-button");
const result = document.querySelector("#result");

fetch("/api/status")
  .then(response => response.json())
  .then(status => {
    document.querySelector("#status").textContent = `Checkout ${status.version}`;
    payButton.disabled = false;
  })
  .catch(() => {
    document.querySelector("#status").textContent = "Checkout status unavailable";
  });

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      cart: { items: [{ price_cents: 1000, quantity: 1 }] },
      method: "card",
    }),
  })
    .then(async response => {
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data.error || `Checkout failed (${response.status})`);
      }
      return data;
    })
    .then(data => {
      const amount = (data.amount_cents / 100).toFixed(2);
      result.textContent = `Payment ${data.status}: $${amount} (${data.method})`;
    })
    .catch(error => {
      result.textContent = `Error: ${error.message}`;
    })
    .finally(() => {
      payButton.disabled = false;
    });
});
