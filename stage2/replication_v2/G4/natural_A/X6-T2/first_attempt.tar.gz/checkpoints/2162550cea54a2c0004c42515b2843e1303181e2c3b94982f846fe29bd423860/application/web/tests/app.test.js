// Minimal DOM/fetch harness so the client wiring in web/app.js can be tested
// with plain `node web/tests/app.test.js` (no external packages).
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const assert = require("assert");

const APP_JS = fs.readFileSync(path.join(__dirname, "..", "app.js"), "utf8");

function makeElement(id) {
  return { id, textContent: "", disabled: false, listeners: {}, addEventListener(ev, fn) { this.listeners[ev] = fn; } };
}

function flush() {
  return new Promise(resolve => setTimeout(resolve, 0));
}

async function run({ statusOk = true, checkoutResponse = null } = {}) {
  const elements = { "#status": makeElement("status"), "#pay-button": makeElement("pay-button"), "#result": makeElement("result") };
  const calls = [];
  const context = {
    document: { querySelector: sel => elements[sel] || null },
    fetch: (url, opts) => {
      calls.push({ url, opts });
      if (url === "/api/status") {
        if (!statusOk) return Promise.reject(new Error("network"));
        return Promise.resolve({ ok: true, json: () => Promise.resolve({ version: "2.0" }) });
      }
      return Promise.resolve(checkoutResponse);
    },
  };
  vm.createContext(context);
  vm.runInContext(APP_JS, context);
  await flush();
  return { elements, calls, payButton: elements["#pay-button"], result: elements["#result"], status: elements["#status"] };
}

const tests = [];
const test = (name, fn) => tests.push({ name, fn });

function jsonResponse(status, body) {
  return { ok: status >= 200 && status < 300, status, json: () => Promise.resolve(body) };
}

test("button exists and starts disabled", async () => {
  const { payButton } = await run({ statusOk: false });
  assert.strictEqual(payButton.disabled, true);
});

test("button enabled after status resolves", async () => {
  const { payButton, status } = await run();
  assert.strictEqual(payButton.disabled, false);
  assert.strictEqual(status.textContent, "Checkout 2.0");
});

test("status failure keeps button disabled and shows message", async () => {
  const { payButton, status } = await run({ statusOk: false });
  assert.strictEqual(payButton.disabled, true);
  assert.strictEqual(status.textContent, "Checkout status unavailable");
});

test("click triggers POST /api/checkout with card payload", async () => {
  const { payButton, calls } = await run({ checkoutResponse: jsonResponse(200, { status: "pending_payment", amount_cents: 1000, method: "card" }) });
  await payButton.listeners.click();
  await flush();
  const post = calls.find(c => c.url === "/api/checkout");
  assert.ok(post, "checkout request should be sent");
  assert.strictEqual(post.opts.method, "POST");
  const body = JSON.parse(post.opts.body);
  assert.strictEqual(body.method, "card");
  assert.ok(Array.isArray(body.cart.items) && body.cart.items.length > 0);
});

test("success renders pending_payment and amount in #result", async () => {
  const { payButton, result } = await run({ checkoutResponse: jsonResponse(200, { status: "pending_payment", amount_cents: 1000, method: "card" }) });
  await payButton.listeners.click();
  await flush();
  assert.strictEqual(result.textContent, "Payment pending_payment: $10.00 (card)");
});

test("non-OK response surfaces error in #result", async () => {
  const { payButton, result } = await run({ checkoutResponse: jsonResponse(400, { error: "The cart needs items with positive quantities" }) });
  await payButton.listeners.click();
  await flush();
  assert.ok(result.textContent.startsWith("Error:"), result.textContent);
  assert.ok(result.textContent.includes("cart needs items"), result.textContent);
});

test("button re-enabled after completion", async () => {
  const { payButton } = await run({ checkoutResponse: jsonResponse(200, { status: "pending_payment", amount_cents: 1000, method: "card" }) });
  await payButton.listeners.click();
  await flush();
  assert.strictEqual(payButton.disabled, false);
});

(async () => {
  let failed = 0;
  for (const { name, fn } of tests) {
    try {
      await fn();
      console.log(`PASS ${name}`);
    } catch (err) {
      failed += 1;
      console.log(`FAIL ${name}: ${err.message}`);
    }
  }
  console.log(`${tests.length - failed}/${tests.length} passed`);
  process.exit(failed ? 1 : 0);
})();
