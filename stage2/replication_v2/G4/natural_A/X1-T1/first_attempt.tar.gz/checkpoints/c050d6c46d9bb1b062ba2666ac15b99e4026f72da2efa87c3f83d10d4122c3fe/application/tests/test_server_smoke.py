"""Runtime smoke test for the HTTP layer and the current release entrypoint.

The pure-logic tests in test_checkout.py never start a server, so they cannot
catch entrypoint/port regressions (e.g. run.py routing to the retired legacy
handler). This test boots the real 2.0 handler on an ephemeral port and
exercises the documented API surface.
"""
import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from checkout_app.server import Handler


class ServerSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)

    def _url(self, path):
        return "http://127.0.0.1:%d%s" % (self.port, path)

    def _request(self, req):
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read())

    def _get(self, path):
        return self._request(urllib.request.Request(self._url(path)))

    def _post(self, path, payload):
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            self._url(path), data=data, headers={"Content-Type": "application/json"}
        )
        return self._request(req)

    def test_status_reports_current_version(self):
        status, body = self._get("/api/status")
        self.assertEqual(status, 200)
        self.assertEqual(body, {"service": "checkout", "version": "2.0"})

    def test_card_checkout_end_to_end(self):
        status, body = self._post(
            "/api/checkout",
            {"cart": {"items": [{"price_cents": 1250, "quantity": 2}]}},
        )
        self.assertEqual(status, 200)
        self.assertEqual(
            body,
            {"status": "pending_payment", "amount_cents": 2500, "method": "card"},
        )

    def test_bank_transfer_method(self):
        status, body = self._post(
            "/api/checkout",
            {"cart": {"items": [{"price_cents": 500, "quantity": 1}]}, "method": "bank_transfer"},
        )
        self.assertEqual(status, 200)
        self.assertEqual(body["method"], "bank_transfer")

    def test_invalid_cart_returns_400(self):
        status, body = self._post("/api/checkout", {"cart": {"items": []}})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_unknown_path_returns_404(self):
        status, body = self._get("/api/nope")
        self.assertEqual(status, 404)
        self.assertEqual(body, {"error": "Not found"})


if __name__ == "__main__":
    unittest.main()
