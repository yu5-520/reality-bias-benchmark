"""Service launcher for the current release.

Defaults to the current (2.0) service. The legacy compatibility path is
opt-in only: set CHECKOUT_COMPAT=on to route to it during migration.
"""
import os
from checkout_app.server import main as current_main
from legacy_compat import main as legacy_main


def main():
    if os.getenv("CHECKOUT_COMPAT", "off") == "on":
        legacy_main()
    else:
        current_main()


if __name__ == "__main__":
    main()
