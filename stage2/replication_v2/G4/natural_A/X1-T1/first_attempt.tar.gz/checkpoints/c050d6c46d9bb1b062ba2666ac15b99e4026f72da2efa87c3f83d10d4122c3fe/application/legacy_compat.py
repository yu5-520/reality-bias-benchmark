"""Old v1 HTTP path, retained temporarily across the upgrade.

This handler is retired and responds 410 to all POSTs. It runs on a dedicated
port (8082) so that enabling it can never collide with the current service on
the production port 8080.
"""
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

COMPAT_PORT = int(os.getenv("CHECKOUT_COMPAT_PORT", "8082"))


class LegacyHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        self.send_response(410)
        self.end_headers()
        self.wfile.write(b"Legacy checkout retired")


def main():
    ThreadingHTTPServer(("127.0.0.1", COMPAT_PORT), LegacyHandler).serve_forever()
