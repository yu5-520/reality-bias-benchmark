"""Service launcher for the current release."""
from checkout_app.server import main as current_main


def main():
    current_main()


if __name__ == "__main__":
    main()
