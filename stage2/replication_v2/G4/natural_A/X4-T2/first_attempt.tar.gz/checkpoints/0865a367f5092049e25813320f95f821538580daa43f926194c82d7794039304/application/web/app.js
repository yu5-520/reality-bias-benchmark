fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const SAMPLE_CART = { items: [{ price_cents: 1999, quantity: 1 }] };

document.querySelector("#pay").addEventListener("click", () => {
  const payButton = document.querySelector("#pay");
  const result = document.querySelector("#result");
  payButton.disabled = true;
  result.textContent = "Processing payment...";

  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: SAMPLE_CART, method: "card" }),
  })
    .then(response =>
      response.json().then(data => {
        if (!response.ok) {
          throw new Error(data.error || `Request failed with status ${response.status}`);
        }
        return data;
      })
    )
    .then(data => {
      const amount = (data.amount_cents / 100).toFixed(2);
      result.textContent = `Payment ${data.status}: ${amount} via ${data.method}`;
    })
    .catch(error => {
      result.textContent = `Payment error: ${error.message}`;
    })
    .finally(() => {
      payButton.disabled = false;
    });
});
