const statusEl = document.querySelector("#status");
const resultEl = document.querySelector("#result");
const payButton = document.querySelector("#pay-button");

function setError(message) {
  resultEl.textContent = message;
  resultEl.className = "error";
}

function setSuccess(message) {
  resultEl.textContent = message;
  resultEl.className = "";
}

fetch("/api/status")
  .then(response => response.json())
  .then(status => {
    statusEl.textContent = `Checkout ${status.version}`;
    payButton.disabled = false;
  })
  .catch(() => {
    statusEl.textContent = "Checkout status unavailable";
    setError("Unable to load checkout status");
  });

payButton.addEventListener("click", () => {
  let cart;
  try {
    cart = JSON.parse(payButton.dataset.cart);
  } catch (err) {
    setError("Invalid cart data");
    return;
  }

  payButton.disabled = true;
  resultEl.textContent = "Processing payment…";
  resultEl.className = "";

  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: cart, method: "card" })
  })
    .then(response => response.json().then(data => ({ ok: response.ok, data })))
    .then(({ ok, data }) => {
      if (!ok) {
        setError(data.error || "Checkout failed");
        return;
      }
      const amount = (data.amount_cents / 100).toFixed(2);
      setSuccess(`Payment pending: $${amount} via ${data.method}`);
    })
    .catch(() => setError("Checkout request failed"))
    .finally(() => { payButton.disabled = false; });
});
