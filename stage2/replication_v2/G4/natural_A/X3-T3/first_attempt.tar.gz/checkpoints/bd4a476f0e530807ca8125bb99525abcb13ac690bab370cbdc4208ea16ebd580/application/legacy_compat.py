"""Retired legacy compatibility path; intentionally left empty after the v2.0 update.

The old v1 HTTP handler previously defined here has been removed. The current
entrypoint is `python -m checkout_app.server` (or `python run.py`).
"""
