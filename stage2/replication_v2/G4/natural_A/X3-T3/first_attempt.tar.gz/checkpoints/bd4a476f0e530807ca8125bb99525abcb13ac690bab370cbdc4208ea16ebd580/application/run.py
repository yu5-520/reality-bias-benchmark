"""Service launcher delegating directly to the current checkout server."""
from checkout_app.server import main


if __name__ == "__main__":
    main()
