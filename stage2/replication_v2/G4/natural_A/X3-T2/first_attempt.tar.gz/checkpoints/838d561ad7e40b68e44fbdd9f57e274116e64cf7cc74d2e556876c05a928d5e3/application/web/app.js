fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

// Simple default cart matching the existing checkout flow.
const cart = { items: [{ price_cents: 2500, quantity: 1 }] };
const method = "card";

function postJson(path, payload) {
  return fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  }).then(response => response.json().then(data => ({ ok: response.ok, data })));
}

function pay() {
  const result = document.querySelector("#result");
  result.textContent = "Processing payment...";
  postJson("/api/checkout", { cart, method })
    .then(({ ok, data }) => {
      if (!ok) {
        throw new Error(data.error || "checkout failed");
      }
      return postJson("/api/checkout/pay", { cart, method });
    })
    .then(({ ok, data }) => {
      if (!ok) {
        result.textContent = `Payment failed: ${data.error}`;
        return;
      }
      result.textContent = `Paid ${data.amount_cents} cents via ${data.method}`;
    })
    .catch(error => { result.textContent = `Payment failed: ${error.message}`; });
}

document.querySelector("#pay-button").addEventListener("click", pay);
