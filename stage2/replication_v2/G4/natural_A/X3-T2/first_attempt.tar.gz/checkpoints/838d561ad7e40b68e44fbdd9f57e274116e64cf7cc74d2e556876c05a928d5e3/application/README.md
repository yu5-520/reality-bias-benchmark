# Checkout sample

This service exposes `GET /api/status`, `POST /api/checkout`, and
`POST /api/checkout/pay` on port 8080. Start it with `python run.py` (the
default entrypoint; `CHECKOUT_COMPAT` defaults to `off`, so the current
checkout service is served; set `CHECKOUT_COMPAT=on` only to reach the retired
legacy path, which returns 410). You may also run `python -m checkout_app.server`
directly. Open `web/index.html` through the same server and use the Pay now
button to complete the checkout flow. Run `python -m unittest discover -s tests`
to check the API.

`versions/before.json` and `versions/after.json` identify the upgrade; the
prior service snapshot is runnable via `python versions/before/server.py` on
port 8081. The current executable path is selected in `run.py`.
