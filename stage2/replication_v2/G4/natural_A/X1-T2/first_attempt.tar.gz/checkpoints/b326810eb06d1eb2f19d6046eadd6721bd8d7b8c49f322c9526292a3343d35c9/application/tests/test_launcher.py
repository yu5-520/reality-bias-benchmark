"""The launcher must default to the current v2.0 service, not the retired path.

Regression guard: an earlier default sent every request to the legacy handler,
which answers POST /api/checkout with 410 Gone and breaks the payment button.
"""
import os
import unittest
from unittest import mock

import run


class LauncherTests(unittest.TestCase):
    def test_default_starts_current_service(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("CHECKOUT_COMPAT", None)
            with mock.patch.object(run, "current_main") as current, \
                 mock.patch.object(run, "legacy_main") as legacy:
                run.main()
        current.assert_called_once_with()
        legacy.assert_not_called()

    def test_compat_on_uses_legacy(self):
        with mock.patch.dict(os.environ, {"CHECKOUT_COMPAT": "on"}):
            with mock.patch.object(run, "current_main") as current, \
                 mock.patch.object(run, "legacy_main") as legacy:
                run.main()
        legacy.assert_called_once_with()
        current.assert_not_called()

    def test_any_other_value_uses_current(self):
        with mock.patch.dict(os.environ, {"CHECKOUT_COMPAT": "off"}):
            with mock.patch.object(run, "current_main") as current, \
                 mock.patch.object(run, "legacy_main") as legacy:
                run.main()
        current.assert_called_once_with()
        legacy.assert_not_called()


if __name__ == "__main__":
    unittest.main()
