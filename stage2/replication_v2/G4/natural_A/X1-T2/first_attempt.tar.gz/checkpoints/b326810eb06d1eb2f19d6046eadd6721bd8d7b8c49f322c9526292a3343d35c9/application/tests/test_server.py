"""HTTP-level tests for the checkout endpoint the payment button calls.

These drive the real Handler over a loopback socket so the request/response
contract the frontend depends on is exercised end to end.
"""
import json
import threading
import unittest
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer

from checkout_app.server import Handler


class ServerTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def request(self, method, path, body=None):
        conn = HTTPConnection("127.0.0.1", self.port, timeout=5)
        headers = {}
        payload = None
        if body is not None:
            payload = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        conn.request(method, path, body=payload, headers=headers)
        response = conn.getresponse()
        data = response.read()
        conn.close()
        return response.status, data

    def json_request(self, method, path, body=None):
        status, data = self.request(method, path, body)
        return status, json.loads(data)


class CheckoutEndpointTests(ServerTestCase):
    def test_status(self):
        status, body = self.json_request("GET", "/api/status")
        self.assertEqual(status, 200)
        self.assertEqual(body, {"service": "checkout", "version": "2.0"})

    def test_card_checkout_matches_frontend_payload(self):
        # Exactly what web/app.js posts.
        payload = {"cart": {"items": [{"price_cents": 1250, "quantity": 2}]}, "method": "card"}
        status, body = self.json_request("POST", "/api/checkout", payload)
        self.assertEqual(status, 200)
        self.assertEqual(body, {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_bank_transfer_method(self):
        payload = {"cart": {"items": [{"price_cents": 500, "quantity": 3}]}, "method": "bank_transfer"}
        status, body = self.json_request("POST", "/api/checkout", payload)
        self.assertEqual(status, 200)
        self.assertEqual(body["method"], "bank_transfer")
        self.assertEqual(body["amount_cents"], 1500)

    def test_method_defaults_to_card(self):
        status, body = self.json_request("POST", "/api/checkout",
                                         {"cart": {"items": [{"price_cents": 100, "quantity": 1}]}})
        self.assertEqual(status, 200)
        self.assertEqual(body["method"], "card")

    def test_empty_cart_is_rejected(self):
        status, body = self.json_request("POST", "/api/checkout", {"cart": {"items": []}})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_unsupported_method_is_rejected(self):
        payload = {"cart": {"items": [{"price_cents": 100, "quantity": 1}]}, "method": "crypto"}
        status, body = self.json_request("POST", "/api/checkout", payload)
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_missing_cart_is_rejected(self):
        status, body = self.json_request("POST", "/api/checkout", {"method": "card"})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_malformed_json_is_rejected(self):
        conn = HTTPConnection("127.0.0.1", self.port, timeout=5)
        conn.request("POST", "/api/checkout", body=b"{not json",
                     headers={"Content-Type": "application/json"})
        response = conn.getresponse()
        data = response.read()
        conn.close()
        self.assertEqual(response.status, 400)
        self.assertIn("error", json.loads(data))

    def test_unknown_path_is_404(self):
        status, body = self.json_request("GET", "/api/nope")
        self.assertEqual(status, 404)
        self.assertIn("error", body)

    def test_unknown_post_path_is_404(self):
        status, body = self.json_request("POST", "/api/other", {})
        self.assertEqual(status, 404)
        self.assertIn("error", body)

    def test_oversized_body_is_rejected(self):
        status, body = self.json_request("POST", "/api/checkout", {"pad": "x" * 70000})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_index_and_app_js_are_served(self):
        status, data = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn(b"Pay now", data)

        status, data = self.request("GET", "/app.js")
        self.assertEqual(status, 200)
        self.assertIn(b"/api/checkout", data)


if __name__ == "__main__":
    unittest.main()
