"""Service launcher.

By default this starts the current v2.0 checkout service. Set
CHECKOUT_COMPAT=on to fall back to the retired v1 compatibility path, which
answers every request with 410 Gone.
"""
import os
from checkout_app.server import main as current_main
from legacy_compat import main as legacy_main


def main():
    if os.getenv("CHECKOUT_COMPAT", "off") == "on":
        legacy_main()
    else:
        current_main()


if __name__ == "__main__":
    main()
