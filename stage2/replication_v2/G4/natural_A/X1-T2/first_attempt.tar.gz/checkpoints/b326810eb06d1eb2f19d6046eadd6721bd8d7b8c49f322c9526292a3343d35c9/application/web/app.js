// Sample cart for the checkout page. In a real app this would come from the
// cart service; the shape matches what POST /api/checkout expects.
const cart = {
  items: [
    { name: "Sample item", price_cents: 1250, quantity: 2 },
  ],
};

function formatCents(cents) {
  return `$${(cents / 100).toFixed(2)}`;
}

function renderCart() {
  const list = document.querySelector("#cart");
  list.replaceChildren(
    ...cart.items.map(item => {
      const li = document.createElement("li");
      li.textContent = `${item.name} × ${item.quantity} — ${formatCents(item.price_cents * item.quantity)}`;
      return li;
    })
  );
  const total = cart.items.reduce((sum, item) => sum + item.price_cents * item.quantity, 0);
  document.querySelector("#total").textContent = formatCents(total);
}

async function pay(method) {
  const response = await fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method }),
  });
  const body = await response.json();
  if (!response.ok) {
    throw new Error(body.error || `Checkout failed (${response.status})`);
  }
  return body;
}

function showResult(message) {
  document.querySelector("#result").textContent = message;
}

document.querySelector("#checkout-form").addEventListener("submit", async event => {
  event.preventDefault();
  const button = document.querySelector("#pay");
  const method = document.querySelector("#method").value;
  button.disabled = true;
  showResult("Processing payment…");
  try {
    const result = await pay(method);
    showResult(`Payment pending: ${formatCents(result.amount_cents)} via ${result.method}.`);
  } catch (error) {
    showResult(`Could not start payment: ${error.message}`);
  } finally {
    button.disabled = false;
  }
});

renderCart();

fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });
