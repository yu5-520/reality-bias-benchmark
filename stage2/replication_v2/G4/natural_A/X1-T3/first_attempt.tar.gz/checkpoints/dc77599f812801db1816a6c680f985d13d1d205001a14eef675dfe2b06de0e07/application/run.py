"""Service launcher for the current release."""
from checkout_app.server import main


def main():
    main()


if __name__ == "__main__":
    main()
