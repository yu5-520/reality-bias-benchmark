"""Retired v1 compatibility path.

The v1 HTTP path was removed as part of the 2.0 upgrade; the current service
lives in ``checkout_app.server``. The historical v1.9 snapshot remains runnable
for comparison via ``python versions/before/server.py`` on port 8081.
"""
