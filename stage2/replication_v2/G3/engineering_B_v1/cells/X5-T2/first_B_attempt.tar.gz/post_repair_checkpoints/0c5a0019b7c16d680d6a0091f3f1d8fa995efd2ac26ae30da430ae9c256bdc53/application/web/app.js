const CART = { items: [{ price_cents: 1999, quantity: 1 }] };

function setStatus(text) {
  document.querySelector("#status").textContent = text;
}

function setResult(text) {
  document.querySelector("#result").textContent = text;
}

fetch("/api/status")
  .then(response => response.json())
  .then(status => { setStatus(`Checkout ${status.version}`); })
  .catch(() => { setStatus("Checkout status unavailable"); });

const payButton = document.querySelector("#pay");

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  setResult("");
  setStatus("Processing payment...");

  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: CART, method: "card" })
  })
    .then(async response => {
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || `Request failed (${response.status})`);
      }
      return data;
    })
    .then(result => {
      const amount = (result.amount_cents / 100).toFixed(2);
      setResult(`Payment ${result.status}: $${amount} via ${result.method}`);
      setStatus("Checkout complete");
    })
    .catch(error => {
      setResult(`Error: ${error.message}`);
      setStatus("Checkout failed");
    })
    .finally(() => {
      payButton.disabled = false;
    });
});
