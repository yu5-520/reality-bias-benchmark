"""HTTP API endpoints for checkout."""

import json

from checkout_app.checkout import create_checkout


def handle_pay(body):
    """Handle a POST /api/pay request body (JSON string or dict).

    Returns a JSON-serializable dict with status, amount_cents, method,
    and an optional message field.
    """
    if isinstance(body, (str, bytes)):
        try:
            body = json.loads(body)
        except (ValueError, TypeError):
            return {"status": "error", "message": "Invalid JSON body"}

    if not isinstance(body, dict):
        return {"status": "error", "message": "Request body must be a JSON object"}

    cart = body.get("cart")
    method = body.get("method", "card")

    if not isinstance(cart, dict):
        return {"status": "error", "message": "A cart object is required"}

    try:
        result = create_checkout(cart, method=method)
    except ValueError as exc:
        return {"status": "error", "message": str(exc)}

    result["message"] = "Payment initiated"
    return result
