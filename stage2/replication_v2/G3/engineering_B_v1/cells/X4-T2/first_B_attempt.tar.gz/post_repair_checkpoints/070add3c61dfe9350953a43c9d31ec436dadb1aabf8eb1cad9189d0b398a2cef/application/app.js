fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const payButton = document.querySelector("#pay-button");
const result = document.querySelector("#result");

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  result.textContent = "Processing payment...";
  fetch("/api/pay", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
  })
    .then(response => response.json())
    .then(data => {
      result.textContent = data.message || "Payment successful";
    })
    .catch(() => {
      result.textContent = "Payment failed. Please try again.";
      payButton.disabled = false;
    });
});
