fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const payButton = document.querySelector("#pay-button");
const resultEl = document.querySelector("#result");

payButton.addEventListener("click", () => {
  const cart = window.__checkoutCart || { items: [] };
  const method = document.querySelector("#payment-method").value;

  resultEl.textContent = "Processing payment...";
  payButton.disabled = true;

  fetch("/api/pay", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method })
  })
    .then(response => response.json())
    .then(result => {
      if (result.status === "error") {
        resultEl.textContent = `Payment failed: ${result.message}`;
        return;
      }
      const amount = (result.amount_cents / 100).toFixed(2);
      resultEl.textContent = `${result.message} - $${amount} via ${result.method} (${result.status})`;
    })
    .catch(() => {
      resultEl.textContent = "Payment failed: network error";
    })
    .finally(() => {
      payButton.disabled = false;
    });
});
