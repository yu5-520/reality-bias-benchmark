fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const paymentContainer = document.querySelector("#payment");
const payButton = document.createElement("button");
payButton.id = "pay-button";
payButton.textContent = "Pay";
payButton.addEventListener("click", () => {
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "pay" })
  })
    .then(response => response.json())
    .then(result => { document.querySelector("#status").textContent = `Payment ${result.status}`; });
});
paymentContainer.appendChild(payButton);
