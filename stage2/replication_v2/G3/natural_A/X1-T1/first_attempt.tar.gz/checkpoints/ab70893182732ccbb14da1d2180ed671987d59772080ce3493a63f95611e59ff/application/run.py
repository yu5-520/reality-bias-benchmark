"""Service launcher.

Serves the current checkout service (v2.0) by default. The legacy v1 HTTP path
is retained for review but must be opted into explicitly via CHECKOUT_COMPAT=on,
so the default deploy path can never shadow the current service.
"""
import os
from checkout_app.server import main as current_main
from legacy_compat import main as legacy_main


def main():
    if os.getenv("CHECKOUT_COMPAT", "off") == "on":
        legacy_main()
    else:
        current_main()


if __name__ == "__main__":
    main()
