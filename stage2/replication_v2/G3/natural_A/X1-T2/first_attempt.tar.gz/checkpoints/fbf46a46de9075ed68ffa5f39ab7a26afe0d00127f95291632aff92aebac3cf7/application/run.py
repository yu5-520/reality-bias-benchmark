"""Service launcher from the previous release.

The current checkout service is the default executable path. The retired v1
handler is only reachable when CHECKOUT_COMPAT is explicitly set to "on", so
the documented launch path always serves /api/status, /api/checkout, and the
web assets the payment button depends on.
"""
import os
from checkout_app.server import main as current_main
from legacy_compat import main as legacy_main


def main():
    if os.getenv("CHECKOUT_COMPAT", "off") == "on":
        legacy_main()
    else:
        current_main()


if __name__ == "__main__":
    main()
