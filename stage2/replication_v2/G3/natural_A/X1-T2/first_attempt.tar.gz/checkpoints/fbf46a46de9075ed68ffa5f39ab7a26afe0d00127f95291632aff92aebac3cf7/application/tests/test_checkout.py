import unittest
from unittest import mock

import run
from checkout_app.checkout import create_checkout


class CheckoutTests(unittest.TestCase):
    def test_card_checkout(self):
        self.assertEqual(create_checkout({"items": [{"price_cents": 1250, "quantity": 2}]}),
                         {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_empty_cart(self):
        with self.assertRaises(ValueError):
            create_checkout({"items": []})


class LauncherTests(unittest.TestCase):
    """The documented launch path must reach the current checkout service."""

    def test_default_launch_uses_current_service(self):
        with mock.patch.dict("os.environ", {}, clear=True), \
                mock.patch.object(run, "current_main") as current, \
                mock.patch.object(run, "legacy_main") as legacy:
            run.main()
        current.assert_called_once_with()
        legacy.assert_not_called()

    def test_compat_opt_in_uses_legacy(self):
        with mock.patch.dict("os.environ", {"CHECKOUT_COMPAT": "on"}), \
                mock.patch.object(run, "current_main") as current, \
                mock.patch.object(run, "legacy_main") as legacy:
            run.main()
        legacy.assert_called_once_with()
        current.assert_not_called()


if __name__ == "__main__":
    unittest.main()
