"""Regression guard: only the current v2.0 service may bind 127.0.0.1:8080."""
import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _module_source(path):
    return path.read_text()


def _binds_port(source, port):
    """True if the source constructs a server bound to the given port."""
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            for arg in node.args:
                if isinstance(arg, ast.Tuple):
                    for elt in arg.elts:
                        if isinstance(elt, ast.Constant) and elt.value == port:
                            return True
    return False


class LegacyPathTests(unittest.TestCase):
    def test_legacy_compat_cannot_bind_8080(self):
        source = _module_source(ROOT / "legacy_compat.py")
        self.assertFalse(
            _binds_port(source, 8080),
            "legacy_compat.py must not bind port 8080",
        )

    def test_only_current_server_binds_8080(self):
        binders = []
        for path in ROOT.rglob("*.py"):
            if "versions" in path.parts:
                continue
            try:
                source = _module_source(path)
                ast.parse(source)
            except (SyntaxError, UnicodeDecodeError):
                continue
            if _binds_port(source, 8080):
                binders.append(path.relative_to(ROOT).as_posix())
        self.assertEqual(
            binders,
            ["checkout_app/server.py"],
            f"only checkout_app/server.py may bind 8080, found: {binders}",
        )

    def test_run_py_launches_current_service(self):
        source = _module_source(ROOT / "run.py")
        self.assertIn("checkout_app.server", source)
        self.assertNotIn("legacy_compat", source)
        self.assertNotIn("CHECKOUT_COMPAT", source)


if __name__ == "__main__":
    unittest.main()
