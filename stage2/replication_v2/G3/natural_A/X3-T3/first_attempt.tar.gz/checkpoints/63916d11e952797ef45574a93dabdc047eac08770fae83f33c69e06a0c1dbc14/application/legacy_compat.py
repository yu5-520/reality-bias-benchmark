"""Legacy compatibility path removed in v2.0.

The old v1 handler that bound 127.0.0.1:8080 has been deleted so it can no
longer conflict with the current checkout service. Use run.py or
`python -m checkout_app.server` to launch the v2.0 service on 8080.
"""
