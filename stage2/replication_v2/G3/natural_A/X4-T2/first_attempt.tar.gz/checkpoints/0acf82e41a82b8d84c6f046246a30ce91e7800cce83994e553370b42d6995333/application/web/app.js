fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const CART = { items: [{ price_cents: 1250, quantity: 2 }] };

const form = document.querySelector("#checkout-form");
const result = document.querySelector("#result");
const payButton = document.querySelector("#pay-button");

form.addEventListener("submit", event => {
  event.preventDefault();
  payButton.disabled = true;
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart: CART, method: document.querySelector("#method").value })
  })
    .then(response => response.json().then(body => ({ ok: response.ok, body })))
    .then(({ ok, body }) => {
      if (!ok) {
        result.textContent = `Payment failed: ${body.error}`;
        return;
      }
      const amount = (body.amount_cents / 100).toFixed(2);
      result.textContent = `Payment ${body.status} for $${amount} via ${body.method}`;
    })
    .catch(() => { result.textContent = "Payment failed: network error"; })
    .finally(() => { payButton.disabled = false; });
});
