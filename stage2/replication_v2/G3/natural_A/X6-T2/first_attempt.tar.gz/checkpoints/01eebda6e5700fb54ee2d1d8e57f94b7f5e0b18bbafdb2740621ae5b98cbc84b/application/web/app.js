fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const payButton = document.querySelector("#pay");
const result = document.querySelector("#result");

payButton.addEventListener("click", () => {
  payButton.disabled = true;
  result.textContent = "Processing payment...";

  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      items: [
        { id: "sample-item", quantity: 1 }
      ]
    })
  })
    .then(response => response.json().then(data => ({ ok: response.ok, data })))
    .then(({ ok, data }) => {
      if (ok) {
        result.textContent = `Paid ${data.amount_cents} cents`;
      } else {
        result.textContent = `Error: ${data.error}`;
      }
    })
    .catch(error => {
      result.textContent = `Error: ${error.message}`;
    })
    .finally(() => {
      payButton.disabled = false;
    });
});
