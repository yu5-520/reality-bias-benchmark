"""HTTP-level tests for /api/checkout against checkout_app.server."""
import json
import threading
import unittest
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer

from checkout_app.server import Handler


def _start_server():
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread


class CheckoutHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server, cls.thread = _start_server()
        cls.port = cls.server.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)

    def _post(self, body, path="/api/checkout", raw=False, content_type="application/json"):
        conn = HTTPConnection("127.0.0.1", self.port, timeout=5)
        payload = body if raw else json.dumps(body)
        if not isinstance(payload, bytes):
            payload = payload.encode()
        conn.request("POST", path, body=payload, headers={"Content-Type": content_type})
        response = conn.getresponse()
        data = response.read()
        conn.close()
        return response.status, data

    def _json(self, body, path="/api/checkout"):
        status, data = self._post(body, path=path)
        return status, json.loads(data)

    def test_status_endpoint_still_works(self):
        conn = HTTPConnection("127.0.0.1", self.port, timeout=5)
        conn.request("GET", "/api/status")
        response = conn.getresponse()
        body = json.loads(response.read())
        conn.close()
        self.assertEqual(response.status, 200)
        self.assertEqual(body, {"service": "checkout", "version": "2.0"})

    def test_happy_path_card(self):
        status, body = self._json({"cart": {"items": [{"price_cents": 1250, "quantity": 2}]}})
        self.assertEqual(status, 200)
        self.assertEqual(body, {"status": "pending_payment", "amount_cents": 2500, "method": "card"})

    def test_bank_transfer(self):
        status, body = self._json({"cart": {"items": [{"price_cents": 500, "quantity": 3}]},
                                  "method": "bank_transfer"})
        self.assertEqual(status, 200)
        self.assertEqual(body["method"], "bank_transfer")
        self.assertEqual(body["amount_cents"], 1500)

    def test_unsupported_method(self):
        status, body = self._json({"cart": {"items": [{"price_cents": 100, "quantity": 1}]},
                                  "method": "crypto"})
        self.assertEqual(status, 400)
        self.assertIn("error", body)
        self.assertIn("method", body["error"].lower())

    def test_zero_quantity(self):
        status, body = self._json({"cart": {"items": [{"price_cents": 100, "quantity": 0}]}})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_negative_quantity(self):
        status, body = self._json({"cart": {"items": [{"price_cents": 100, "quantity": -1}]}})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_empty_cart(self):
        status, body = self._json({"cart": {"items": []}})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_missing_price_cents(self):
        status, body = self._json({"cart": {"items": [{"quantity": 1}]}})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_negative_price_cents(self):
        # create_checkout validates price_cents < 1, so a negative price is
        # rejected and surfaces as a 400 with an error JSON body.
        status, body = self._json({"cart": {"items": [{"price_cents": -5, "quantity": 1}]}})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_malformed_payload_missing_cart(self):
        status, body = self._json({"method": "card"})
        self.assertEqual(status, 400)
        self.assertIn("error", body)

    def test_non_json_body(self):
        status, data = self._post("not json at all", raw=True)
        self.assertEqual(status, 400)
        body = json.loads(data)
        self.assertIn("error", body)

    def test_unknown_path_404(self):
        status, body = self._json({"cart": {"items": []}}, path="/api/nope")
        self.assertEqual(status, 404)
        self.assertIn("error", body)


if __name__ == "__main__":
    unittest.main()
