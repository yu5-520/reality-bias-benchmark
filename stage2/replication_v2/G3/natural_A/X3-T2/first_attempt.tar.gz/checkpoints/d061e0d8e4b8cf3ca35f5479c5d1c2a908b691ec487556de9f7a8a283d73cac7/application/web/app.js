fetch("/api/status")
  .then(response => response.json())
  .then(status => { document.querySelector("#status").textContent = `Checkout ${status.version}`; });

const form = document.querySelector("#checkout-form");
const payButton = document.querySelector("#pay-button");
const result = document.querySelector("#result");

function readCart() {
  const priceCents = Number(document.querySelector("#price-cents").value);
  const quantity = Number(document.querySelector("#quantity").value);
  if (!Number.isFinite(priceCents) || priceCents < 1 || !Number.isInteger(quantity) || quantity < 1) {
    throw new Error("Enter a positive price and quantity");
  }
  return { items: [{ price_cents: priceCents, quantity }] };
}

form.addEventListener("submit", event => {
  event.preventDefault();
  let cart;
  try {
    cart = readCart();
  } catch (error) {
    result.textContent = `Error: ${error.message}`;
    return;
  }
  const method = document.querySelector("#method").value;
  payButton.disabled = true;
  result.textContent = "Processing payment...";
  fetch("/api/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart, method })
  })
    .then(response =>
      response.json()
        .catch(() => ({ error: `Request failed with status ${response.status}` }))
        .then(body => ({ ok: response.ok, status: response.status, body }))
    )
    .then(({ ok, status, body }) => {
      if (ok) {
        result.textContent = `Payment ${body.status}: ${body.amount_cents} cents via ${body.method} (HTTP ${status})`;
      } else {
        result.textContent = `Error (HTTP ${status}): ${body.error}`;
      }
    })
    .catch(error => { result.textContent = `Network error: ${error.message}`; })
    .finally(() => { payButton.disabled = false; });
});
